/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.15.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.15.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[50];
    char stringdata0[828];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 6), // "order1"
QT_MOC_LITERAL(2, 18, 0), // ""
QT_MOC_LITERAL(3, 19, 6), // "hurry1"
QT_MOC_LITERAL(4, 26, 9), // "NeedHelp1"
QT_MOC_LITERAL(5, 36, 6), // "order2"
QT_MOC_LITERAL(6, 43, 6), // "hurry2"
QT_MOC_LITERAL(7, 50, 9), // "NeedHelp2"
QT_MOC_LITERAL(8, 60, 6), // "order3"
QT_MOC_LITERAL(9, 67, 6), // "hurry3"
QT_MOC_LITERAL(10, 74, 9), // "NeedHelp3"
QT_MOC_LITERAL(11, 84, 6), // "order4"
QT_MOC_LITERAL(12, 91, 6), // "hurry4"
QT_MOC_LITERAL(13, 98, 9), // "NeedHelp4"
QT_MOC_LITERAL(14, 108, 6), // "order5"
QT_MOC_LITERAL(15, 115, 6), // "hurry5"
QT_MOC_LITERAL(16, 122, 9), // "NeedHelp5"
QT_MOC_LITERAL(17, 132, 6), // "order6"
QT_MOC_LITERAL(18, 139, 6), // "hurry6"
QT_MOC_LITERAL(19, 146, 9), // "NeedHelp6"
QT_MOC_LITERAL(20, 156, 12), // "popupWindow1"
QT_MOC_LITERAL(21, 169, 12), // "popupWindow2"
QT_MOC_LITERAL(22, 182, 12), // "popupWindow3"
QT_MOC_LITERAL(23, 195, 12), // "popupWindow4"
QT_MOC_LITERAL(24, 208, 12), // "popupWindow5"
QT_MOC_LITERAL(25, 221, 12), // "popupWindow6"
QT_MOC_LITERAL(26, 234, 23), // "on_pushButton_3_clicked"
QT_MOC_LITERAL(27, 258, 24), // "on_pushButton_25_clicked"
QT_MOC_LITERAL(28, 283, 24), // "on_pushButton_26_clicked"
QT_MOC_LITERAL(29, 308, 23), // "on_pushButton_5_clicked"
QT_MOC_LITERAL(30, 332, 23), // "on_pushButton_6_clicked"
QT_MOC_LITERAL(31, 356, 23), // "on_pushButton_7_clicked"
QT_MOC_LITERAL(32, 380, 24), // "on_pushButton_28_clicked"
QT_MOC_LITERAL(33, 405, 23), // "on_pushButton_8_clicked"
QT_MOC_LITERAL(34, 429, 23), // "on_pushButton_9_clicked"
QT_MOC_LITERAL(35, 453, 24), // "on_pushButton_10_clicked"
QT_MOC_LITERAL(36, 478, 24), // "on_pushButton_11_clicked"
QT_MOC_LITERAL(37, 503, 24), // "on_pushButton_12_clicked"
QT_MOC_LITERAL(38, 528, 24), // "on_pushButton_13_clicked"
QT_MOC_LITERAL(39, 553, 24), // "on_pushButton_14_clicked"
QT_MOC_LITERAL(40, 578, 24), // "on_pushButton_15_clicked"
QT_MOC_LITERAL(41, 603, 24), // "on_pushButton_16_clicked"
QT_MOC_LITERAL(42, 628, 24), // "on_pushButton_17_clicked"
QT_MOC_LITERAL(43, 653, 24), // "on_pushButton_18_clicked"
QT_MOC_LITERAL(44, 678, 24), // "on_pushButton_19_clicked"
QT_MOC_LITERAL(45, 703, 24), // "on_pushButton_20_clicked"
QT_MOC_LITERAL(46, 728, 24), // "on_pushButton_21_clicked"
QT_MOC_LITERAL(47, 753, 24), // "on_pushButton_22_clicked"
QT_MOC_LITERAL(48, 778, 24), // "on_pushButton_23_clicked"
QT_MOC_LITERAL(49, 803, 24) // "on_pushButton_24_clicked"

    },
    "MainWindow\0order1\0\0hurry1\0NeedHelp1\0"
    "order2\0hurry2\0NeedHelp2\0order3\0hurry3\0"
    "NeedHelp3\0order4\0hurry4\0NeedHelp4\0"
    "order5\0hurry5\0NeedHelp5\0order6\0hurry6\0"
    "NeedHelp6\0popupWindow1\0popupWindow2\0"
    "popupWindow3\0popupWindow4\0popupWindow5\0"
    "popupWindow6\0on_pushButton_3_clicked\0"
    "on_pushButton_25_clicked\0"
    "on_pushButton_26_clicked\0"
    "on_pushButton_5_clicked\0on_pushButton_6_clicked\0"
    "on_pushButton_7_clicked\0"
    "on_pushButton_28_clicked\0"
    "on_pushButton_8_clicked\0on_pushButton_9_clicked\0"
    "on_pushButton_10_clicked\0"
    "on_pushButton_11_clicked\0"
    "on_pushButton_12_clicked\0"
    "on_pushButton_13_clicked\0"
    "on_pushButton_14_clicked\0"
    "on_pushButton_15_clicked\0"
    "on_pushButton_16_clicked\0"
    "on_pushButton_17_clicked\0"
    "on_pushButton_18_clicked\0"
    "on_pushButton_19_clicked\0"
    "on_pushButton_20_clicked\0"
    "on_pushButton_21_clicked\0"
    "on_pushButton_22_clicked\0"
    "on_pushButton_23_clicked\0"
    "on_pushButton_24_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      48,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
      24,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,  254,    2, 0x06 /* Public */,
       3,    0,  255,    2, 0x06 /* Public */,
       4,    0,  256,    2, 0x06 /* Public */,
       5,    0,  257,    2, 0x06 /* Public */,
       6,    0,  258,    2, 0x06 /* Public */,
       7,    0,  259,    2, 0x06 /* Public */,
       8,    0,  260,    2, 0x06 /* Public */,
       9,    0,  261,    2, 0x06 /* Public */,
      10,    0,  262,    2, 0x06 /* Public */,
      11,    0,  263,    2, 0x06 /* Public */,
      12,    0,  264,    2, 0x06 /* Public */,
      13,    0,  265,    2, 0x06 /* Public */,
      14,    0,  266,    2, 0x06 /* Public */,
      15,    0,  267,    2, 0x06 /* Public */,
      16,    0,  268,    2, 0x06 /* Public */,
      17,    0,  269,    2, 0x06 /* Public */,
      18,    0,  270,    2, 0x06 /* Public */,
      19,    0,  271,    2, 0x06 /* Public */,
      20,    0,  272,    2, 0x06 /* Public */,
      21,    0,  273,    2, 0x06 /* Public */,
      22,    0,  274,    2, 0x06 /* Public */,
      23,    0,  275,    2, 0x06 /* Public */,
      24,    0,  276,    2, 0x06 /* Public */,
      25,    0,  277,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      26,    0,  278,    2, 0x08 /* Private */,
      27,    0,  279,    2, 0x08 /* Private */,
      28,    0,  280,    2, 0x08 /* Private */,
      29,    0,  281,    2, 0x08 /* Private */,
      30,    0,  282,    2, 0x08 /* Private */,
      31,    0,  283,    2, 0x08 /* Private */,
      32,    0,  284,    2, 0x08 /* Private */,
      33,    0,  285,    2, 0x08 /* Private */,
      34,    0,  286,    2, 0x08 /* Private */,
      35,    0,  287,    2, 0x08 /* Private */,
      36,    0,  288,    2, 0x08 /* Private */,
      37,    0,  289,    2, 0x08 /* Private */,
      38,    0,  290,    2, 0x08 /* Private */,
      39,    0,  291,    2, 0x08 /* Private */,
      40,    0,  292,    2, 0x08 /* Private */,
      41,    0,  293,    2, 0x08 /* Private */,
      42,    0,  294,    2, 0x08 /* Private */,
      43,    0,  295,    2, 0x08 /* Private */,
      44,    0,  296,    2, 0x08 /* Private */,
      45,    0,  297,    2, 0x08 /* Private */,
      46,    0,  298,    2, 0x08 /* Private */,
      47,    0,  299,    2, 0x08 /* Private */,
      48,    0,  300,    2, 0x08 /* Private */,
      49,    0,  301,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->order1(); break;
        case 1: _t->hurry1(); break;
        case 2: _t->NeedHelp1(); break;
        case 3: _t->order2(); break;
        case 4: _t->hurry2(); break;
        case 5: _t->NeedHelp2(); break;
        case 6: _t->order3(); break;
        case 7: _t->hurry3(); break;
        case 8: _t->NeedHelp3(); break;
        case 9: _t->order4(); break;
        case 10: _t->hurry4(); break;
        case 11: _t->NeedHelp4(); break;
        case 12: _t->order5(); break;
        case 13: _t->hurry5(); break;
        case 14: _t->NeedHelp5(); break;
        case 15: _t->order6(); break;
        case 16: _t->hurry6(); break;
        case 17: _t->NeedHelp6(); break;
        case 18: _t->popupWindow1(); break;
        case 19: _t->popupWindow2(); break;
        case 20: _t->popupWindow3(); break;
        case 21: _t->popupWindow4(); break;
        case 22: _t->popupWindow5(); break;
        case 23: _t->popupWindow6(); break;
        case 24: _t->on_pushButton_3_clicked(); break;
        case 25: _t->on_pushButton_25_clicked(); break;
        case 26: _t->on_pushButton_26_clicked(); break;
        case 27: _t->on_pushButton_5_clicked(); break;
        case 28: _t->on_pushButton_6_clicked(); break;
        case 29: _t->on_pushButton_7_clicked(); break;
        case 30: _t->on_pushButton_28_clicked(); break;
        case 31: _t->on_pushButton_8_clicked(); break;
        case 32: _t->on_pushButton_9_clicked(); break;
        case 33: _t->on_pushButton_10_clicked(); break;
        case 34: _t->on_pushButton_11_clicked(); break;
        case 35: _t->on_pushButton_12_clicked(); break;
        case 36: _t->on_pushButton_13_clicked(); break;
        case 37: _t->on_pushButton_14_clicked(); break;
        case 38: _t->on_pushButton_15_clicked(); break;
        case 39: _t->on_pushButton_16_clicked(); break;
        case 40: _t->on_pushButton_17_clicked(); break;
        case 41: _t->on_pushButton_18_clicked(); break;
        case 42: _t->on_pushButton_19_clicked(); break;
        case 43: _t->on_pushButton_20_clicked(); break;
        case 44: _t->on_pushButton_21_clicked(); break;
        case 45: _t->on_pushButton_22_clicked(); break;
        case 46: _t->on_pushButton_23_clicked(); break;
        case 47: _t->on_pushButton_24_clicked(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (MainWindow::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::order1)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::hurry1)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::NeedHelp1)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::order2)) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::hurry2)) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::NeedHelp2)) {
                *result = 5;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::order3)) {
                *result = 6;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::hurry3)) {
                *result = 7;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::NeedHelp3)) {
                *result = 8;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::order4)) {
                *result = 9;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::hurry4)) {
                *result = 10;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::NeedHelp4)) {
                *result = 11;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::order5)) {
                *result = 12;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::hurry5)) {
                *result = 13;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::NeedHelp5)) {
                *result = 14;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::order6)) {
                *result = 15;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::hurry6)) {
                *result = 16;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::NeedHelp6)) {
                *result = 17;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::popupWindow1)) {
                *result = 18;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::popupWindow2)) {
                *result = 19;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::popupWindow3)) {
                *result = 20;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::popupWindow4)) {
                *result = 21;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::popupWindow5)) {
                *result = 22;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::popupWindow6)) {
                *result = 23;
                return;
            }
        }
    }
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject MainWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_MainWindow.data,
    qt_meta_data_MainWindow,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 48)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 48;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 48)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 48;
    }
    return _id;
}

// SIGNAL 0
void MainWindow::order1()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void MainWindow::hurry1()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}

// SIGNAL 2
void MainWindow::NeedHelp1()
{
    QMetaObject::activate(this, &staticMetaObject, 2, nullptr);
}

// SIGNAL 3
void MainWindow::order2()
{
    QMetaObject::activate(this, &staticMetaObject, 3, nullptr);
}

// SIGNAL 4
void MainWindow::hurry2()
{
    QMetaObject::activate(this, &staticMetaObject, 4, nullptr);
}

// SIGNAL 5
void MainWindow::NeedHelp2()
{
    QMetaObject::activate(this, &staticMetaObject, 5, nullptr);
}

// SIGNAL 6
void MainWindow::order3()
{
    QMetaObject::activate(this, &staticMetaObject, 6, nullptr);
}

// SIGNAL 7
void MainWindow::hurry3()
{
    QMetaObject::activate(this, &staticMetaObject, 7, nullptr);
}

// SIGNAL 8
void MainWindow::NeedHelp3()
{
    QMetaObject::activate(this, &staticMetaObject, 8, nullptr);
}

// SIGNAL 9
void MainWindow::order4()
{
    QMetaObject::activate(this, &staticMetaObject, 9, nullptr);
}

// SIGNAL 10
void MainWindow::hurry4()
{
    QMetaObject::activate(this, &staticMetaObject, 10, nullptr);
}

// SIGNAL 11
void MainWindow::NeedHelp4()
{
    QMetaObject::activate(this, &staticMetaObject, 11, nullptr);
}

// SIGNAL 12
void MainWindow::order5()
{
    QMetaObject::activate(this, &staticMetaObject, 12, nullptr);
}

// SIGNAL 13
void MainWindow::hurry5()
{
    QMetaObject::activate(this, &staticMetaObject, 13, nullptr);
}

// SIGNAL 14
void MainWindow::NeedHelp5()
{
    QMetaObject::activate(this, &staticMetaObject, 14, nullptr);
}

// SIGNAL 15
void MainWindow::order6()
{
    QMetaObject::activate(this, &staticMetaObject, 15, nullptr);
}

// SIGNAL 16
void MainWindow::hurry6()
{
    QMetaObject::activate(this, &staticMetaObject, 16, nullptr);
}

// SIGNAL 17
void MainWindow::NeedHelp6()
{
    QMetaObject::activate(this, &staticMetaObject, 17, nullptr);
}

// SIGNAL 18
void MainWindow::popupWindow1()
{
    QMetaObject::activate(this, &staticMetaObject, 18, nullptr);
}

// SIGNAL 19
void MainWindow::popupWindow2()
{
    QMetaObject::activate(this, &staticMetaObject, 19, nullptr);
}

// SIGNAL 20
void MainWindow::popupWindow3()
{
    QMetaObject::activate(this, &staticMetaObject, 20, nullptr);
}

// SIGNAL 21
void MainWindow::popupWindow4()
{
    QMetaObject::activate(this, &staticMetaObject, 21, nullptr);
}

// SIGNAL 22
void MainWindow::popupWindow5()
{
    QMetaObject::activate(this, &staticMetaObject, 22, nullptr);
}

// SIGNAL 23
void MainWindow::popupWindow6()
{
    QMetaObject::activate(this, &staticMetaObject, 23, nullptr);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
