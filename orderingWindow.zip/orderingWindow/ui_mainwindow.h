/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.15.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFrame>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QFrame *frame_2;
    QPushButton *pushButton_5;
    QPushButton *pushButton_6;
    QPushButton *pushButton_7;
    QPushButton *pushButton_8;
    QLabel *label_2;
    QFrame *frame_3;
    QPushButton *pushButton_9;
    QPushButton *pushButton_10;
    QPushButton *pushButton_11;
    QPushButton *pushButton_12;
    QLabel *label_3;
    QFrame *frame_4;
    QPushButton *pushButton_13;
    QPushButton *pushButton_14;
    QPushButton *pushButton_15;
    QPushButton *pushButton_16;
    QLabel *label_4;
    QFrame *frame_5;
    QPushButton *pushButton_17;
    QPushButton *pushButton_18;
    QPushButton *pushButton_19;
    QPushButton *pushButton_20;
    QLabel *label_5;
    QFrame *frame_6;
    QPushButton *pushButton_21;
    QPushButton *pushButton_22;
    QPushButton *pushButton_23;
    QPushButton *pushButton_24;
    QLabel *label_6;
    QFrame *frame_7;
    QPushButton *pushButton_25;
    QPushButton *pushButton_26;
    QPushButton *pushButton_28;
    QLabel *label_7;
    QPushButton *pushButton_3;
    QMenuBar *menubar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(800, 600);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        frame_2 = new QFrame(centralwidget);
        frame_2->setObjectName(QString::fromUtf8("frame_2"));
        frame_2->setGeometry(QRect(260, 100, 121, 181));
        frame_2->setFrameShape(QFrame::StyledPanel);
        frame_2->setFrameShadow(QFrame::Raised);
        pushButton_5 = new QPushButton(frame_2);
        pushButton_5->setObjectName(QString::fromUtf8("pushButton_5"));
        pushButton_5->setGeometry(QRect(20, 50, 75, 23));
        pushButton_6 = new QPushButton(frame_2);
        pushButton_6->setObjectName(QString::fromUtf8("pushButton_6"));
        pushButton_6->setGeometry(QRect(20, 80, 75, 23));
        pushButton_7 = new QPushButton(frame_2);
        pushButton_7->setObjectName(QString::fromUtf8("pushButton_7"));
        pushButton_7->setGeometry(QRect(20, 110, 75, 23));
        pushButton_8 = new QPushButton(frame_2);
        pushButton_8->setObjectName(QString::fromUtf8("pushButton_8"));
        pushButton_8->setGeometry(QRect(20, 140, 75, 23));
        label_2 = new QLabel(frame_2);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(10, 15, 51, 21));
        frame_3 = new QFrame(centralwidget);
        frame_3->setObjectName(QString::fromUtf8("frame_3"));
        frame_3->setGeometry(QRect(440, 100, 121, 181));
        frame_3->setFrameShape(QFrame::StyledPanel);
        frame_3->setFrameShadow(QFrame::Raised);
        pushButton_9 = new QPushButton(frame_3);
        pushButton_9->setObjectName(QString::fromUtf8("pushButton_9"));
        pushButton_9->setGeometry(QRect(20, 50, 75, 23));
        pushButton_10 = new QPushButton(frame_3);
        pushButton_10->setObjectName(QString::fromUtf8("pushButton_10"));
        pushButton_10->setGeometry(QRect(20, 80, 75, 23));
        pushButton_11 = new QPushButton(frame_3);
        pushButton_11->setObjectName(QString::fromUtf8("pushButton_11"));
        pushButton_11->setGeometry(QRect(20, 110, 75, 23));
        pushButton_12 = new QPushButton(frame_3);
        pushButton_12->setObjectName(QString::fromUtf8("pushButton_12"));
        pushButton_12->setGeometry(QRect(20, 140, 75, 23));
        label_3 = new QLabel(frame_3);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(10, 15, 51, 21));
        frame_4 = new QFrame(centralwidget);
        frame_4->setObjectName(QString::fromUtf8("frame_4"));
        frame_4->setGeometry(QRect(80, 310, 121, 181));
        frame_4->setFrameShape(QFrame::StyledPanel);
        frame_4->setFrameShadow(QFrame::Raised);
        pushButton_13 = new QPushButton(frame_4);
        pushButton_13->setObjectName(QString::fromUtf8("pushButton_13"));
        pushButton_13->setGeometry(QRect(20, 50, 75, 23));
        pushButton_14 = new QPushButton(frame_4);
        pushButton_14->setObjectName(QString::fromUtf8("pushButton_14"));
        pushButton_14->setGeometry(QRect(20, 80, 75, 23));
        pushButton_15 = new QPushButton(frame_4);
        pushButton_15->setObjectName(QString::fromUtf8("pushButton_15"));
        pushButton_15->setGeometry(QRect(20, 110, 75, 23));
        pushButton_16 = new QPushButton(frame_4);
        pushButton_16->setObjectName(QString::fromUtf8("pushButton_16"));
        pushButton_16->setGeometry(QRect(20, 140, 75, 23));
        label_4 = new QLabel(frame_4);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(10, 15, 51, 21));
        frame_5 = new QFrame(centralwidget);
        frame_5->setObjectName(QString::fromUtf8("frame_5"));
        frame_5->setGeometry(QRect(260, 310, 121, 181));
        frame_5->setFrameShape(QFrame::StyledPanel);
        frame_5->setFrameShadow(QFrame::Raised);
        pushButton_17 = new QPushButton(frame_5);
        pushButton_17->setObjectName(QString::fromUtf8("pushButton_17"));
        pushButton_17->setGeometry(QRect(20, 50, 75, 23));
        pushButton_18 = new QPushButton(frame_5);
        pushButton_18->setObjectName(QString::fromUtf8("pushButton_18"));
        pushButton_18->setGeometry(QRect(20, 80, 75, 23));
        pushButton_19 = new QPushButton(frame_5);
        pushButton_19->setObjectName(QString::fromUtf8("pushButton_19"));
        pushButton_19->setGeometry(QRect(20, 110, 75, 23));
        pushButton_20 = new QPushButton(frame_5);
        pushButton_20->setObjectName(QString::fromUtf8("pushButton_20"));
        pushButton_20->setGeometry(QRect(20, 140, 75, 23));
        label_5 = new QLabel(frame_5);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(10, 15, 51, 21));
        frame_6 = new QFrame(centralwidget);
        frame_6->setObjectName(QString::fromUtf8("frame_6"));
        frame_6->setGeometry(QRect(440, 310, 121, 181));
        frame_6->setFrameShape(QFrame::StyledPanel);
        frame_6->setFrameShadow(QFrame::Raised);
        pushButton_21 = new QPushButton(frame_6);
        pushButton_21->setObjectName(QString::fromUtf8("pushButton_21"));
        pushButton_21->setGeometry(QRect(20, 50, 75, 23));
        pushButton_22 = new QPushButton(frame_6);
        pushButton_22->setObjectName(QString::fromUtf8("pushButton_22"));
        pushButton_22->setGeometry(QRect(20, 80, 75, 23));
        pushButton_23 = new QPushButton(frame_6);
        pushButton_23->setObjectName(QString::fromUtf8("pushButton_23"));
        pushButton_23->setGeometry(QRect(20, 110, 75, 23));
        pushButton_24 = new QPushButton(frame_6);
        pushButton_24->setObjectName(QString::fromUtf8("pushButton_24"));
        pushButton_24->setGeometry(QRect(20, 140, 75, 23));
        label_6 = new QLabel(frame_6);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(10, 15, 51, 21));
        frame_7 = new QFrame(centralwidget);
        frame_7->setObjectName(QString::fromUtf8("frame_7"));
        frame_7->setGeometry(QRect(80, 100, 121, 181));
        frame_7->setFrameShape(QFrame::StyledPanel);
        frame_7->setFrameShadow(QFrame::Raised);
        pushButton_25 = new QPushButton(frame_7);
        pushButton_25->setObjectName(QString::fromUtf8("pushButton_25"));
        pushButton_25->setGeometry(QRect(20, 50, 75, 23));
        pushButton_26 = new QPushButton(frame_7);
        pushButton_26->setObjectName(QString::fromUtf8("pushButton_26"));
        pushButton_26->setGeometry(QRect(20, 80, 75, 23));
        pushButton_28 = new QPushButton(frame_7);
        pushButton_28->setObjectName(QString::fromUtf8("pushButton_28"));
        pushButton_28->setGeometry(QRect(20, 140, 75, 23));
        label_7 = new QLabel(frame_7);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setGeometry(QRect(10, 15, 51, 21));
        pushButton_3 = new QPushButton(frame_7);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));
        pushButton_3->setGeometry(QRect(20, 110, 75, 23));
        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 800, 25));
        MainWindow->setMenuBar(menubar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        pushButton_5->setText(QCoreApplication::translate("MainWindow", "Order", nullptr));
        pushButton_6->setText(QCoreApplication::translate("MainWindow", "Hurry", nullptr));
        pushButton_7->setText(QCoreApplication::translate("MainWindow", "Need Help", nullptr));
        pushButton_8->setText(QCoreApplication::translate("MainWindow", "Check out", nullptr));
        label_2->setText(QCoreApplication::translate("MainWindow", "Table 2", nullptr));
        pushButton_9->setText(QCoreApplication::translate("MainWindow", "Order", nullptr));
        pushButton_10->setText(QCoreApplication::translate("MainWindow", "Hurry", nullptr));
        pushButton_11->setText(QCoreApplication::translate("MainWindow", "Need Help", nullptr));
        pushButton_12->setText(QCoreApplication::translate("MainWindow", "Check out", nullptr));
        label_3->setText(QCoreApplication::translate("MainWindow", "Table 3", nullptr));
        pushButton_13->setText(QCoreApplication::translate("MainWindow", "Order", nullptr));
        pushButton_14->setText(QCoreApplication::translate("MainWindow", "Hurry", nullptr));
        pushButton_15->setText(QCoreApplication::translate("MainWindow", "Need Help", nullptr));
        pushButton_16->setText(QCoreApplication::translate("MainWindow", "Check out", nullptr));
        label_4->setText(QCoreApplication::translate("MainWindow", "Table 4", nullptr));
        pushButton_17->setText(QCoreApplication::translate("MainWindow", "Order", nullptr));
        pushButton_18->setText(QCoreApplication::translate("MainWindow", "Hurry", nullptr));
        pushButton_19->setText(QCoreApplication::translate("MainWindow", "Need Help", nullptr));
        pushButton_20->setText(QCoreApplication::translate("MainWindow", "Check out", nullptr));
        label_5->setText(QCoreApplication::translate("MainWindow", "Table 5", nullptr));
        pushButton_21->setText(QCoreApplication::translate("MainWindow", "Order", nullptr));
        pushButton_22->setText(QCoreApplication::translate("MainWindow", "Hurry", nullptr));
        pushButton_23->setText(QCoreApplication::translate("MainWindow", "Need Help", nullptr));
        pushButton_24->setText(QCoreApplication::translate("MainWindow", "Check out", nullptr));
        label_6->setText(QCoreApplication::translate("MainWindow", "Table 6", nullptr));
        pushButton_25->setText(QCoreApplication::translate("MainWindow", "Order", nullptr));
        pushButton_26->setText(QCoreApplication::translate("MainWindow", "Hurry", nullptr));
        pushButton_28->setText(QCoreApplication::translate("MainWindow", "Check out", nullptr));
        label_7->setText(QCoreApplication::translate("MainWindow", "Table 1", nullptr));
        pushButton_3->setText(QCoreApplication::translate("MainWindow", "Need Help", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
