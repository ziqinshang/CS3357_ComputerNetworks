/********************************************************************************
** Form generated from reading UI file 'menu.ui'
**
** Created by: Qt User Interface Compiler version 5.15.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MENU_H
#define UI_MENU_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFrame>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QFrame *line;
    QPushButton *pushButton;
    QLabel *Recommend;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *chicken;
    QLabel *pizza;
    QLabel *label_6;
    QLabel *label_4;
    QLabel *label_5;
    QFrame *line_2;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;
    QLabel *label_7;
    QLabel *label_8;
    QLabel *label_9;
    QLabel *label_10;
    QLabel *label_11;
    QLabel *label_12;
    QLabel *label_13;
    QLabel *label_14;
    QLabel *label_15;
    QLabel *label_16;
    QFrame *line_3;
    QLabel *label_17;
    QLabel *label_18;
    QLabel *label_19;
    QLabel *label_20;
    QLabel *label_21;
    QLabel *label_22;
    QLabel *label_23;
    QLabel *label_24;
    QLabel *label_25;
    QPushButton *pushButton_4;
    QPushButton *pushButton_5;
    QPushButton *pushButton_6;
    QPushButton *pushButton_7;
    QPushButton *pushButton_8;
    QPushButton *pushButton_9;
    QPushButton *pushButton_10;
    QPushButton *pushButton_11;
    QPushButton *pushButton_12;
    QPushButton *pushButton_13;
    QLabel *label_26;
    QTextEdit *textEdit;
    QLabel *label;
    QLabel *label_27;
    QLabel *label_28;
    QLabel *label_29;
    QLabel *label_30;
    QLabel *label_31;
    QLabel *label_32;
    QLabel *label_33;
    QLabel *label_34;
    QLabel *label_35;
    QLabel *label_37;
    QLabel *label_38;
    QLabel *label_36;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(1013, 987);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        line = new QFrame(centralWidget);
        line->setObjectName(QString::fromUtf8("line"));
        line->setGeometry(QRect(-20, 280, 1491, 20));
        line->setFrameShape(QFrame::HLine);
        line->setFrameShadow(QFrame::Sunken);
        pushButton = new QPushButton(centralWidget);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(40, 600, 31, 23));
        Recommend = new QLabel(centralWidget);
        Recommend->setObjectName(QString::fromUtf8("Recommend"));
        Recommend->setGeometry(QRect(140, 10, 201, 41));
        Recommend->setStyleSheet(QString::fromUtf8("font: 14pt \"Arial\";\n"
"text-decoration: underline;\n"
""));
        label_2 = new QLabel(centralWidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(40, 40, 211, 221));
        label_3 = new QLabel(centralWidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(260, 50, 211, 201));
        chicken = new QLabel(centralWidget);
        chicken->setObjectName(QString::fromUtf8("chicken"));
        chicken->setGeometry(QRect(100, 260, 81, 31));
        pizza = new QLabel(centralWidget);
        pizza->setObjectName(QString::fromUtf8("pizza"));
        pizza->setGeometry(QRect(340, 260, 54, 31));
        label_6 = new QLabel(centralWidget);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(690, 10, 161, 31));
        label_6->setStyleSheet(QString::fromUtf8("font: 14pt \"Arial\";\n"
"text-decoration: underline;"));
        label_4 = new QLabel(centralWidget);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(670, 40, 181, 211));
        label_5 = new QLabel(centralWidget);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(700, 260, 141, 31));
        line_2 = new QFrame(centralWidget);
        line_2->setObjectName(QString::fromUtf8("line_2"));
        line_2->setGeometry(QRect(510, -20, 20, 311));
        line_2->setFrameShape(QFrame::VLine);
        line_2->setFrameShadow(QFrame::Sunken);
        pushButton_2 = new QPushButton(centralWidget);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(900, 860, 81, 31));
        pushButton_2->setStyleSheet(QString::fromUtf8("font: 11pt \"Arial\";"));
        pushButton_3 = new QPushButton(centralWidget);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));
        pushButton_3->setGeometry(QRect(120, 600, 31, 23));
        label_7 = new QLabel(centralWidget);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setGeometry(QRect(20, 340, 171, 191));
        label_8 = new QLabel(centralWidget);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        label_8->setGeometry(QRect(40, 530, 111, 16));
        label_8->setStyleSheet(QString::fromUtf8("font: 11pt \"Arial\";"));
        label_9 = new QLabel(centralWidget);
        label_9->setObjectName(QString::fromUtf8("label_9"));
        label_9->setGeometry(QRect(30, 550, 151, 21));
        label_9->setStyleSheet(QString::fromUtf8("\n"
"font: 11pt \"Arial\";\n"
""));
        label_10 = new QLabel(centralWidget);
        label_10->setObjectName(QString::fromUtf8("label_10"));
        label_10->setGeometry(QRect(50, 580, 54, 12));
        label_10->setStyleSheet(QString::fromUtf8("font: 11pt \"Arial\";\n"
""));
        label_11 = new QLabel(centralWidget);
        label_11->setObjectName(QString::fromUtf8("label_11"));
        label_11->setGeometry(QRect(250, 350, 181, 171));
        label_12 = new QLabel(centralWidget);
        label_12->setObjectName(QString::fromUtf8("label_12"));
        label_12->setGeometry(QRect(320, 540, 61, 16));
        label_12->setStyleSheet(QString::fromUtf8("font: 11pt \"Arial\";"));
        label_13 = new QLabel(centralWidget);
        label_13->setObjectName(QString::fromUtf8("label_13"));
        label_13->setGeometry(QRect(480, 340, 211, 191));
        label_14 = new QLabel(centralWidget);
        label_14->setObjectName(QString::fromUtf8("label_14"));
        label_14->setGeometry(QRect(10, 630, 211, 211));
        label_15 = new QLabel(centralWidget);
        label_15->setObjectName(QString::fromUtf8("label_15"));
        label_15->setGeometry(QRect(490, 630, 221, 251));
        label_16 = new QLabel(centralWidget);
        label_16->setObjectName(QString::fromUtf8("label_16"));
        label_16->setGeometry(QRect(250, 640, 221, 191));
        line_3 = new QFrame(centralWidget);
        line_3->setObjectName(QString::fromUtf8("line_3"));
        line_3->setGeometry(QRect(710, 290, 20, 691));
        line_3->setFrameShape(QFrame::VLine);
        line_3->setFrameShadow(QFrame::Sunken);
        label_17 = new QLabel(centralWidget);
        label_17->setObjectName(QString::fromUtf8("label_17"));
        label_17->setGeometry(QRect(80, 830, 91, 16));
        label_17->setStyleSheet(QString::fromUtf8("font: 11pt \"Arial\";"));
        label_18 = new QLabel(centralWidget);
        label_18->setObjectName(QString::fromUtf8("label_18"));
        label_18->setGeometry(QRect(330, 840, 54, 12));
        label_18->setStyleSheet(QString::fromUtf8("font: 11pt \"Arial\";"));
        label_19 = new QLabel(centralWidget);
        label_19->setObjectName(QString::fromUtf8("label_19"));
        label_19->setGeometry(QRect(560, 830, 91, 21));
        label_19->setStyleSheet(QString::fromUtf8("font: 11pt \"Arial\";"));
        label_20 = new QLabel(centralWidget);
        label_20->setObjectName(QString::fromUtf8("label_20"));
        label_20->setGeometry(QRect(560, 540, 54, 12));
        label_20->setStyleSheet(QString::fromUtf8("font: 11pt \"Arial\";"));
        label_21 = new QLabel(centralWidget);
        label_21->setObjectName(QString::fromUtf8("label_21"));
        label_21->setGeometry(QRect(330, 560, 54, 12));
        label_21->setStyleSheet(QString::fromUtf8("\n"
"font: 11pt \"Arial\";"));
        label_22 = new QLabel(centralWidget);
        label_22->setObjectName(QString::fromUtf8("label_22"));
        label_22->setGeometry(QRect(570, 560, 54, 12));
        label_22->setStyleSheet(QString::fromUtf8("\n"
"font: 11pt \"Arial\";"));
        label_23 = new QLabel(centralWidget);
        label_23->setObjectName(QString::fromUtf8("label_23"));
        label_23->setGeometry(QRect(90, 850, 54, 12));
        label_23->setStyleSheet(QString::fromUtf8("\n"
"font: 11pt \"Arial\";"));
        label_24 = new QLabel(centralWidget);
        label_24->setObjectName(QString::fromUtf8("label_24"));
        label_24->setGeometry(QRect(330, 860, 54, 12));
        label_24->setStyleSheet(QString::fromUtf8("\n"
"font: 11pt \"Arial\";"));
        label_25 = new QLabel(centralWidget);
        label_25->setObjectName(QString::fromUtf8("label_25"));
        label_25->setGeometry(QRect(580, 850, 54, 12));
        label_25->setStyleSheet(QString::fromUtf8("\n"
"font: 11pt \"Arial\";"));
        pushButton_4 = new QPushButton(centralWidget);
        pushButton_4->setObjectName(QString::fromUtf8("pushButton_4"));
        pushButton_4->setGeometry(QRect(290, 600, 31, 23));
        pushButton_5 = new QPushButton(centralWidget);
        pushButton_5->setObjectName(QString::fromUtf8("pushButton_5"));
        pushButton_5->setGeometry(QRect(380, 600, 31, 23));
        pushButton_6 = new QPushButton(centralWidget);
        pushButton_6->setObjectName(QString::fromUtf8("pushButton_6"));
        pushButton_6->setGeometry(QRect(530, 600, 31, 23));
        pushButton_7 = new QPushButton(centralWidget);
        pushButton_7->setObjectName(QString::fromUtf8("pushButton_7"));
        pushButton_7->setGeometry(QRect(620, 600, 31, 23));
        pushButton_8 = new QPushButton(centralWidget);
        pushButton_8->setObjectName(QString::fromUtf8("pushButton_8"));
        pushButton_8->setGeometry(QRect(30, 900, 31, 23));
        pushButton_9 = new QPushButton(centralWidget);
        pushButton_9->setObjectName(QString::fromUtf8("pushButton_9"));
        pushButton_9->setGeometry(QRect(130, 900, 31, 23));
        pushButton_10 = new QPushButton(centralWidget);
        pushButton_10->setObjectName(QString::fromUtf8("pushButton_10"));
        pushButton_10->setGeometry(QRect(280, 900, 31, 23));
        pushButton_11 = new QPushButton(centralWidget);
        pushButton_11->setObjectName(QString::fromUtf8("pushButton_11"));
        pushButton_11->setGeometry(QRect(390, 900, 31, 23));
        pushButton_12 = new QPushButton(centralWidget);
        pushButton_12->setObjectName(QString::fromUtf8("pushButton_12"));
        pushButton_12->setGeometry(QRect(530, 900, 31, 23));
        pushButton_13 = new QPushButton(centralWidget);
        pushButton_13->setObjectName(QString::fromUtf8("pushButton_13"));
        pushButton_13->setGeometry(QRect(620, 900, 31, 23));
        label_26 = new QLabel(centralWidget);
        label_26->setObjectName(QString::fromUtf8("label_26"));
        label_26->setGeometry(QRect(750, 310, 121, 21));
        label_26->setStyleSheet(QString::fromUtf8("font: 14pt \"Arial\";\n"
"text-decoration: underline;"));
        textEdit = new QTextEdit(centralWidget);
        textEdit->setObjectName(QString::fromUtf8("textEdit"));
        textEdit->setGeometry(QRect(750, 340, 221, 501));
        label = new QLabel(centralWidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(330, 310, 111, 21));
        label->setStyleSheet(QString::fromUtf8("font: 14pt \"Arial\";\n"
"text-decoration: underline;"));
        label_27 = new QLabel(centralWidget);
        label_27->setObjectName(QString::fromUtf8("label_27"));
        label_27->setGeometry(QRect(320, 580, 54, 12));
        label_27->setStyleSheet(QString::fromUtf8("font: 11pt \"Arial\";"));
        label_28 = new QLabel(centralWidget);
        label_28->setObjectName(QString::fromUtf8("label_28"));
        label_28->setGeometry(QRect(560, 580, 54, 12));
        label_28->setStyleSheet(QString::fromUtf8("font: 11pt \"Arial\";"));
        label_29 = new QLabel(centralWidget);
        label_29->setObjectName(QString::fromUtf8("label_29"));
        label_29->setGeometry(QRect(70, 870, 54, 12));
        label_29->setStyleSheet(QString::fromUtf8("font: 11pt \"Arial\";"));
        label_30 = new QLabel(centralWidget);
        label_30->setObjectName(QString::fromUtf8("label_30"));
        label_30->setGeometry(QRect(320, 880, 54, 12));
        label_30->setStyleSheet(QString::fromUtf8("font: 11pt \"Arial\";"));
        label_31 = new QLabel(centralWidget);
        label_31->setObjectName(QString::fromUtf8("label_31"));
        label_31->setGeometry(QRect(560, 870, 54, 12));
        label_31->setStyleSheet(QString::fromUtf8("font: 11pt \"Arial\";"));
        label_32 = new QLabel(centralWidget);
        label_32->setObjectName(QString::fromUtf8("label_32"));
        label_32->setGeometry(QRect(110, 580, 54, 12));
        label_32->setStyleSheet(QString::fromUtf8("font: 11pt \"Arial\";"));
        label_33 = new QLabel(centralWidget);
        label_33->setObjectName(QString::fromUtf8("label_33"));
        label_33->setGeometry(QRect(370, 580, 54, 12));
        label_33->setStyleSheet(QString::fromUtf8("font: 11pt \"Arial\";"));
        label_34 = new QLabel(centralWidget);
        label_34->setObjectName(QString::fromUtf8("label_34"));
        label_34->setGeometry(QRect(610, 580, 54, 12));
        label_34->setStyleSheet(QString::fromUtf8("font: 11pt \"Arial\";"));
        label_35 = new QLabel(centralWidget);
        label_35->setObjectName(QString::fromUtf8("label_35"));
        label_35->setGeometry(QRect(120, 870, 54, 12));
        label_35->setStyleSheet(QString::fromUtf8("font: 11pt \"Arial\";"));
        label_37 = new QLabel(centralWidget);
        label_37->setObjectName(QString::fromUtf8("label_37"));
        label_37->setGeometry(QRect(610, 870, 54, 12));
        label_37->setStyleSheet(QString::fromUtf8("font: 11pt \"Arial\";"));
        label_38 = new QLabel(centralWidget);
        label_38->setObjectName(QString::fromUtf8("label_38"));
        label_38->setGeometry(QRect(900, 900, 81, 31));
        label_38->setStyleSheet(QString::fromUtf8("font: 11pt \"Arial\";"));
        label_36 = new QLabel(centralWidget);
        label_36->setObjectName(QString::fromUtf8("label_36"));
        label_36->setGeometry(QRect(380, 880, 54, 12));
        label_36->setStyleSheet(QString::fromUtf8("font: 11pt \"Arial\";"));
        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 1013, 23));
        MainWindow->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName(QString::fromUtf8("mainToolBar"));
        MainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        MainWindow->setStatusBar(statusBar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        pushButton->setText(QCoreApplication::translate("MainWindow", "+", nullptr));
        Recommend->setText(QCoreApplication::translate("MainWindow", "Recommended Dishes", nullptr));
        label_2->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><img src=\":/new/prefix1/images/chicken.jpg\"/></p></body></html>", nullptr));
        label_3->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><img src=\":/new/prefix1/images/pizza.jpg\"/></p></body></html>", nullptr));
        chicken->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:12pt; font-weight:600;\">Chicken</span></p></body></html>", nullptr));
        pizza->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:12pt; font-weight:600;\">Pizza</span></p></body></html>", nullptr));
        label_6->setText(QCoreApplication::translate("MainWindow", "Discounted Dish", nullptr));
        label_4->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><img src=\":/new/prefix1/images/Chicken_Tacos.jpg\"/></p></body></html>", nullptr));
        label_5->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:12pt; font-weight:600;\">Chicken Tacos</span></p></body></html>", nullptr));
        pushButton_2->setText(QCoreApplication::translate("MainWindow", "Submit", nullptr));
        pushButton_3->setText(QCoreApplication::translate("MainWindow", "-", nullptr));
        label_7->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><img src=\":/new/prefix1/images/Chicken_Tacos.jpg\"/></p></body></html>", nullptr));
        label_8->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p>Chicken Tacos</p></body></html>", nullptr));
        label_9->setText(QCoreApplication::translate("MainWindow", "$5.99 (Original: $7.99)", nullptr));
        label_10->setText(QCoreApplication::translate("MainWindow", "Rate:", nullptr));
        label_11->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><img src=\":/new/prefix1/images/chicken.jpg\"/></p></body></html>", nullptr));
        label_12->setText(QCoreApplication::translate("MainWindow", "Chicken", nullptr));
        label_13->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><img src=\":/new/prefix1/images/coffee.jpg\"/></p></body></html>", nullptr));
        label_14->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><img src=\":/new/prefix1/images/french_fries.jpg\"/></p></body></html>", nullptr));
        label_15->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><img src=\":/new/prefix1/images/onion_rings.jpg\"/></p><p><br/></p></body></html>", nullptr));
        label_16->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><img src=\":/new/prefix1/images/pizza.jpg\"/></p></body></html>", nullptr));
        label_17->setText(QCoreApplication::translate("MainWindow", "French Fires", nullptr));
        label_18->setText(QCoreApplication::translate("MainWindow", "Pizza", nullptr));
        label_19->setText(QCoreApplication::translate("MainWindow", "Onion Rings", nullptr));
        label_20->setText(QCoreApplication::translate("MainWindow", "Coffee", nullptr));
        label_21->setText(QCoreApplication::translate("MainWindow", "$6.99", nullptr));
        label_22->setText(QCoreApplication::translate("MainWindow", "$2.99", nullptr));
        label_23->setText(QCoreApplication::translate("MainWindow", "$3.99", nullptr));
        label_24->setText(QCoreApplication::translate("MainWindow", "$10.99", nullptr));
        label_25->setText(QCoreApplication::translate("MainWindow", "$5.99", nullptr));
        pushButton_4->setText(QCoreApplication::translate("MainWindow", "+", nullptr));
        pushButton_5->setText(QCoreApplication::translate("MainWindow", "-", nullptr));
        pushButton_6->setText(QCoreApplication::translate("MainWindow", "+", nullptr));
        pushButton_7->setText(QCoreApplication::translate("MainWindow", "-", nullptr));
        pushButton_8->setText(QCoreApplication::translate("MainWindow", "+", nullptr));
        pushButton_9->setText(QCoreApplication::translate("MainWindow", "-", nullptr));
        pushButton_10->setText(QCoreApplication::translate("MainWindow", "+", nullptr));
        pushButton_11->setText(QCoreApplication::translate("MainWindow", "-", nullptr));
        pushButton_12->setText(QCoreApplication::translate("MainWindow", "+", nullptr));
        pushButton_13->setText(QCoreApplication::translate("MainWindow", "-", nullptr));
        label_26->setText(QCoreApplication::translate("MainWindow", "Order items:", nullptr));
        label->setText(QCoreApplication::translate("MainWindow", "Menu", nullptr));
        label_27->setText(QCoreApplication::translate("MainWindow", "Rate:", nullptr));
        label_28->setText(QCoreApplication::translate("MainWindow", "Rate:", nullptr));
        label_29->setText(QCoreApplication::translate("MainWindow", "Rate:", nullptr));
        label_30->setText(QCoreApplication::translate("MainWindow", "Rate:", nullptr));
        label_31->setText(QCoreApplication::translate("MainWindow", "Rate:", nullptr));
        label_32->setText(QString());
        label_33->setText(QString());
        label_34->setText(QString());
        label_35->setText(QString());
        label_37->setText(QString());
        label_38->setText(QString());
        label_36->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MENU_H
