/********************************************************************************
** Form generated from reading UI file 'dialog.ui'
**
** Created by: Qt User Interface Compiler version 5.15.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIALOG_H
#define UI_DIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QFrame>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextEdit>

QT_BEGIN_NAMESPACE

class Ui_Dialog
{
public:
    QLabel *label_21;
    QPushButton *pushButton_6;
    QLabel *label;
    QLabel *label_34;
    QLabel *label_36;
    QLabel *label_3;
    QLabel *pizza;
    QPushButton *pushButton_2;
    QLabel *label_12;
    QPushButton *pushButton_8;
    QLabel *label_18;
    QFrame *line_3;
    QPushButton *pushButton_3;
    QLabel *chicken;
    QLabel *label_35;
    QLabel *label_29;
    QPushButton *pushButton;
    QTextEdit *textEdit;
    QLabel *label_37;
    QLabel *label_10;
    QLabel *label_8;
    QLabel *label_16;
    QLabel *label_9;
    QLabel *label_5;
    QLabel *label_30;
    QPushButton *pushButton_4;
    QLabel *label_6;
    QLabel *label_17;
    QFrame *line_2;
    QLabel *Recommend;
    QLabel *label_11;
    QPushButton *pushButton_11;
    QLabel *label_13;
    QPushButton *pushButton_13;
    QPushButton *pushButton_5;
    QLabel *label_22;
    QLabel *label_2;
    QLabel *label_15;
    QLabel *label_33;
    QLabel *label_19;
    QLabel *label_26;
    QPushButton *pushButton_12;
    QLabel *label_25;
    QLabel *label_24;
    QLabel *label_4;
    QPushButton *pushButton_9;
    QLabel *label_23;
    QPushButton *pushButton_7;
    QFrame *line;
    QPushButton *pushButton_10;
    QLabel *label_28;
    QLabel *label_31;
    QLabel *label_14;
    QLabel *label_27;
    QLabel *label_38;
    QLabel *label_20;
    QLabel *label_32;
    QLabel *label_7;
    QLabel *label_39;
    QLabel *label_40;

    void setupUi(QDialog *Dialog)
    {
        if (Dialog->objectName().isEmpty())
            Dialog->setObjectName(QString::fromUtf8("Dialog"));
        Dialog->resize(1163, 1025);
        label_21 = new QLabel(Dialog);
        label_21->setObjectName(QString::fromUtf8("label_21"));
        label_21->setGeometry(QRect(340, 590, 54, 12));
        label_21->setStyleSheet(QString::fromUtf8("\n"
"font: 11pt \"Arial\";"));
        pushButton_6 = new QPushButton(Dialog);
        pushButton_6->setObjectName(QString::fromUtf8("pushButton_6"));
        pushButton_6->setGeometry(QRect(540, 630, 31, 23));
        label = new QLabel(Dialog);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(340, 340, 111, 21));
        label->setStyleSheet(QString::fromUtf8("font: 14pt \"Arial\";\n"
"text-decoration: underline;"));
        label_34 = new QLabel(Dialog);
        label_34->setObjectName(QString::fromUtf8("label_34"));
        label_34->setGeometry(QRect(620, 610, 54, 12));
        label_34->setStyleSheet(QString::fromUtf8("font: 11pt \"Arial\";"));
        label_36 = new QLabel(Dialog);
        label_36->setObjectName(QString::fromUtf8("label_36"));
        label_36->setGeometry(QRect(390, 910, 54, 12));
        label_36->setStyleSheet(QString::fromUtf8("font: 11pt \"Arial\";"));
        label_3 = new QLabel(Dialog);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(270, 80, 211, 201));
        pizza = new QLabel(Dialog);
        pizza->setObjectName(QString::fromUtf8("pizza"));
        pizza->setGeometry(QRect(350, 290, 54, 31));
        pushButton_2 = new QPushButton(Dialog);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(910, 890, 81, 31));
        pushButton_2->setStyleSheet(QString::fromUtf8("font: 11pt \"Arial\";"));
        label_12 = new QLabel(Dialog);
        label_12->setObjectName(QString::fromUtf8("label_12"));
        label_12->setGeometry(QRect(330, 570, 61, 16));
        label_12->setStyleSheet(QString::fromUtf8("font: 11pt \"Arial\";"));
        pushButton_8 = new QPushButton(Dialog);
        pushButton_8->setObjectName(QString::fromUtf8("pushButton_8"));
        pushButton_8->setGeometry(QRect(40, 930, 31, 23));
        label_18 = new QLabel(Dialog);
        label_18->setObjectName(QString::fromUtf8("label_18"));
        label_18->setGeometry(QRect(340, 870, 54, 12));
        label_18->setStyleSheet(QString::fromUtf8("font: 11pt \"Arial\";"));
        line_3 = new QFrame(Dialog);
        line_3->setObjectName(QString::fromUtf8("line_3"));
        line_3->setGeometry(QRect(720, 320, 20, 691));
        line_3->setFrameShape(QFrame::VLine);
        line_3->setFrameShadow(QFrame::Sunken);
        pushButton_3 = new QPushButton(Dialog);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));
        pushButton_3->setGeometry(QRect(130, 630, 31, 23));
        chicken = new QLabel(Dialog);
        chicken->setObjectName(QString::fromUtf8("chicken"));
        chicken->setGeometry(QRect(110, 290, 81, 31));
        label_35 = new QLabel(Dialog);
        label_35->setObjectName(QString::fromUtf8("label_35"));
        label_35->setGeometry(QRect(130, 900, 54, 12));
        label_35->setStyleSheet(QString::fromUtf8("font: 11pt \"Arial\";"));
        label_29 = new QLabel(Dialog);
        label_29->setObjectName(QString::fromUtf8("label_29"));
        label_29->setGeometry(QRect(80, 900, 54, 12));
        label_29->setStyleSheet(QString::fromUtf8("font: 11pt \"Arial\";"));
        pushButton = new QPushButton(Dialog);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(50, 630, 31, 23));
        textEdit = new QTextEdit(Dialog);
        textEdit->setObjectName(QString::fromUtf8("textEdit"));
        textEdit->setGeometry(QRect(760, 370, 221, 501));
        label_37 = new QLabel(Dialog);
        label_37->setObjectName(QString::fromUtf8("label_37"));
        label_37->setGeometry(QRect(620, 900, 54, 12));
        label_37->setStyleSheet(QString::fromUtf8("font: 11pt \"Arial\";"));
        label_10 = new QLabel(Dialog);
        label_10->setObjectName(QString::fromUtf8("label_10"));
        label_10->setGeometry(QRect(60, 610, 54, 12));
        label_10->setStyleSheet(QString::fromUtf8("font: 11pt \"Arial\";\n"
""));
        label_8 = new QLabel(Dialog);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        label_8->setGeometry(QRect(50, 560, 111, 16));
        label_8->setStyleSheet(QString::fromUtf8("font: 11pt \"Arial\";"));
        label_16 = new QLabel(Dialog);
        label_16->setObjectName(QString::fromUtf8("label_16"));
        label_16->setGeometry(QRect(260, 670, 221, 191));
        label_9 = new QLabel(Dialog);
        label_9->setObjectName(QString::fromUtf8("label_9"));
        label_9->setGeometry(QRect(40, 580, 151, 21));
        label_9->setStyleSheet(QString::fromUtf8("\n"
"font: 11pt \"Arial\";\n"
""));
        label_5 = new QLabel(Dialog);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(710, 290, 141, 31));
        label_30 = new QLabel(Dialog);
        label_30->setObjectName(QString::fromUtf8("label_30"));
        label_30->setGeometry(QRect(330, 910, 54, 12));
        label_30->setStyleSheet(QString::fromUtf8("font: 11pt \"Arial\";"));
        pushButton_4 = new QPushButton(Dialog);
        pushButton_4->setObjectName(QString::fromUtf8("pushButton_4"));
        pushButton_4->setGeometry(QRect(300, 630, 31, 23));
        label_6 = new QLabel(Dialog);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(700, 40, 161, 31));
        label_6->setStyleSheet(QString::fromUtf8("font: 14pt \"Arial\";\n"
"text-decoration: underline;"));
        label_17 = new QLabel(Dialog);
        label_17->setObjectName(QString::fromUtf8("label_17"));
        label_17->setGeometry(QRect(90, 860, 91, 16));
        label_17->setStyleSheet(QString::fromUtf8("font: 11pt \"Arial\";"));
        line_2 = new QFrame(Dialog);
        line_2->setObjectName(QString::fromUtf8("line_2"));
        line_2->setGeometry(QRect(520, 10, 20, 311));
        line_2->setFrameShape(QFrame::VLine);
        line_2->setFrameShadow(QFrame::Sunken);
        Recommend = new QLabel(Dialog);
        Recommend->setObjectName(QString::fromUtf8("Recommend"));
        Recommend->setGeometry(QRect(150, 40, 201, 41));
        Recommend->setStyleSheet(QString::fromUtf8("font: 14pt \"Arial\";\n"
"text-decoration: underline;\n"
""));
        label_11 = new QLabel(Dialog);
        label_11->setObjectName(QString::fromUtf8("label_11"));
        label_11->setGeometry(QRect(260, 380, 181, 171));
        pushButton_11 = new QPushButton(Dialog);
        pushButton_11->setObjectName(QString::fromUtf8("pushButton_11"));
        pushButton_11->setGeometry(QRect(400, 930, 31, 23));
        label_13 = new QLabel(Dialog);
        label_13->setObjectName(QString::fromUtf8("label_13"));
        label_13->setGeometry(QRect(490, 370, 211, 191));
        pushButton_13 = new QPushButton(Dialog);
        pushButton_13->setObjectName(QString::fromUtf8("pushButton_13"));
        pushButton_13->setGeometry(QRect(630, 930, 31, 23));
        pushButton_5 = new QPushButton(Dialog);
        pushButton_5->setObjectName(QString::fromUtf8("pushButton_5"));
        pushButton_5->setGeometry(QRect(390, 630, 31, 23));
        label_22 = new QLabel(Dialog);
        label_22->setObjectName(QString::fromUtf8("label_22"));
        label_22->setGeometry(QRect(580, 590, 54, 12));
        label_22->setStyleSheet(QString::fromUtf8("\n"
"font: 11pt \"Arial\";"));
        label_2 = new QLabel(Dialog);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(50, 70, 211, 221));
        label_15 = new QLabel(Dialog);
        label_15->setObjectName(QString::fromUtf8("label_15"));
        label_15->setGeometry(QRect(500, 640, 221, 251));
        label_33 = new QLabel(Dialog);
        label_33->setObjectName(QString::fromUtf8("label_33"));
        label_33->setGeometry(QRect(380, 610, 54, 12));
        label_33->setStyleSheet(QString::fromUtf8("font: 11pt \"Arial\";"));
        label_19 = new QLabel(Dialog);
        label_19->setObjectName(QString::fromUtf8("label_19"));
        label_19->setGeometry(QRect(570, 860, 91, 21));
        label_19->setStyleSheet(QString::fromUtf8("font: 11pt \"Arial\";"));
        label_26 = new QLabel(Dialog);
        label_26->setObjectName(QString::fromUtf8("label_26"));
        label_26->setGeometry(QRect(760, 340, 121, 21));
        label_26->setStyleSheet(QString::fromUtf8("font: 14pt \"Arial\";\n"
"text-decoration: underline;"));
        pushButton_12 = new QPushButton(Dialog);
        pushButton_12->setObjectName(QString::fromUtf8("pushButton_12"));
        pushButton_12->setGeometry(QRect(540, 930, 31, 23));
        label_25 = new QLabel(Dialog);
        label_25->setObjectName(QString::fromUtf8("label_25"));
        label_25->setGeometry(QRect(590, 880, 54, 12));
        label_25->setStyleSheet(QString::fromUtf8("\n"
"font: 11pt \"Arial\";"));
        label_24 = new QLabel(Dialog);
        label_24->setObjectName(QString::fromUtf8("label_24"));
        label_24->setGeometry(QRect(340, 890, 54, 12));
        label_24->setStyleSheet(QString::fromUtf8("\n"
"font: 11pt \"Arial\";"));
        label_4 = new QLabel(Dialog);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(680, 70, 181, 211));
        pushButton_9 = new QPushButton(Dialog);
        pushButton_9->setObjectName(QString::fromUtf8("pushButton_9"));
        pushButton_9->setGeometry(QRect(140, 930, 31, 23));
        label_23 = new QLabel(Dialog);
        label_23->setObjectName(QString::fromUtf8("label_23"));
        label_23->setGeometry(QRect(100, 880, 54, 12));
        label_23->setStyleSheet(QString::fromUtf8("\n"
"font: 11pt \"Arial\";"));
        pushButton_7 = new QPushButton(Dialog);
        pushButton_7->setObjectName(QString::fromUtf8("pushButton_7"));
        pushButton_7->setGeometry(QRect(630, 630, 31, 23));
        line = new QFrame(Dialog);
        line->setObjectName(QString::fromUtf8("line"));
        line->setGeometry(QRect(-10, 310, 1491, 20));
        line->setFrameShape(QFrame::HLine);
        line->setFrameShadow(QFrame::Sunken);
        pushButton_10 = new QPushButton(Dialog);
        pushButton_10->setObjectName(QString::fromUtf8("pushButton_10"));
        pushButton_10->setGeometry(QRect(290, 930, 31, 23));
        label_28 = new QLabel(Dialog);
        label_28->setObjectName(QString::fromUtf8("label_28"));
        label_28->setGeometry(QRect(570, 610, 54, 12));
        label_28->setStyleSheet(QString::fromUtf8("font: 11pt \"Arial\";"));
        label_31 = new QLabel(Dialog);
        label_31->setObjectName(QString::fromUtf8("label_31"));
        label_31->setGeometry(QRect(570, 900, 54, 12));
        label_31->setStyleSheet(QString::fromUtf8("font: 11pt \"Arial\";"));
        label_14 = new QLabel(Dialog);
        label_14->setObjectName(QString::fromUtf8("label_14"));
        label_14->setGeometry(QRect(20, 660, 211, 211));
        label_27 = new QLabel(Dialog);
        label_27->setObjectName(QString::fromUtf8("label_27"));
        label_27->setGeometry(QRect(330, 610, 54, 12));
        label_27->setStyleSheet(QString::fromUtf8("font: 11pt \"Arial\";"));
        label_38 = new QLabel(Dialog);
        label_38->setObjectName(QString::fromUtf8("label_38"));
        label_38->setGeometry(QRect(910, 930, 81, 31));
        label_38->setStyleSheet(QString::fromUtf8("font: 11pt \"Arial\";"));
        label_20 = new QLabel(Dialog);
        label_20->setObjectName(QString::fromUtf8("label_20"));
        label_20->setGeometry(QRect(570, 570, 54, 12));
        label_20->setStyleSheet(QString::fromUtf8("font: 11pt \"Arial\";"));
        label_32 = new QLabel(Dialog);
        label_32->setObjectName(QString::fromUtf8("label_32"));
        label_32->setGeometry(QRect(120, 610, 54, 12));
        label_32->setStyleSheet(QString::fromUtf8("font: 11pt \"Arial\";"));
        label_7 = new QLabel(Dialog);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setGeometry(QRect(30, 370, 171, 191));
        label_39 = new QLabel(Dialog);
        label_39->setObjectName(QString::fromUtf8("label_39"));
        label_39->setGeometry(QRect(60, 10, 121, 31));
        QFont font;
        font.setPointSize(12);
        label_39->setFont(font);
        label_40 = new QLabel(Dialog);
        label_40->setObjectName(QString::fromUtf8("label_40"));
        label_40->setGeometry(QRect(110, 20, 47, 13));
        label_40->setFont(font);

        retranslateUi(Dialog);

        QMetaObject::connectSlotsByName(Dialog);
    } // setupUi

    void retranslateUi(QDialog *Dialog)
    {
        Dialog->setWindowTitle(QCoreApplication::translate("Dialog", "Dialog", nullptr));
        label_21->setText(QCoreApplication::translate("Dialog", "$6.99", nullptr));
        pushButton_6->setText(QCoreApplication::translate("Dialog", "+", nullptr));
        label->setText(QCoreApplication::translate("Dialog", "Menu", nullptr));
        label_34->setText(QString());
        label_36->setText(QString());
        label_3->setText(QCoreApplication::translate("Dialog", "<html><head/><body><p><img src=\":/images/pizza.jpg\"/></p></body></html>", nullptr));
        pizza->setText(QCoreApplication::translate("Dialog", "<html><head/><body><p><span style=\" font-size:12pt; font-weight:600;\">Pizza</span></p></body></html>", nullptr));
        pushButton_2->setText(QCoreApplication::translate("Dialog", "Submit", nullptr));
        label_12->setText(QCoreApplication::translate("Dialog", "Chicken", nullptr));
        pushButton_8->setText(QCoreApplication::translate("Dialog", "+", nullptr));
        label_18->setText(QCoreApplication::translate("Dialog", "Pizza", nullptr));
        pushButton_3->setText(QCoreApplication::translate("Dialog", "-", nullptr));
        chicken->setText(QCoreApplication::translate("Dialog", "<html><head/><body><p><span style=\" font-size:12pt; font-weight:600;\">Chicken</span></p></body></html>", nullptr));
        label_35->setText(QString());
        label_29->setText(QCoreApplication::translate("Dialog", "Rate:", nullptr));
        pushButton->setText(QCoreApplication::translate("Dialog", "+", nullptr));
        label_37->setText(QString());
        label_10->setText(QCoreApplication::translate("Dialog", "Rate:", nullptr));
        label_8->setText(QCoreApplication::translate("Dialog", "<html><head/><body><p>Chicken Tacos</p></body></html>", nullptr));
        label_16->setText(QCoreApplication::translate("Dialog", "<html><head/><body><p><img src=\":/images/pizza.jpg\"/></p></body></html>", nullptr));
        label_9->setText(QCoreApplication::translate("Dialog", "$5.99 (Original: $7.99)", nullptr));
        label_5->setText(QCoreApplication::translate("Dialog", "<html><head/><body><p><span style=\" font-size:12pt; font-weight:600;\">Chicken Tacos</span></p></body></html>", nullptr));
        label_30->setText(QCoreApplication::translate("Dialog", "Rate:", nullptr));
        pushButton_4->setText(QCoreApplication::translate("Dialog", "+", nullptr));
        label_6->setText(QCoreApplication::translate("Dialog", "Discounted Dish", nullptr));
        label_17->setText(QCoreApplication::translate("Dialog", "French Fires", nullptr));
        Recommend->setText(QCoreApplication::translate("Dialog", "Recommended Dishes", nullptr));
        label_11->setText(QCoreApplication::translate("Dialog", "<html><head/><body><p><img src=\":/images/chicken.jpg\"/></p></body></html>", nullptr));
        pushButton_11->setText(QCoreApplication::translate("Dialog", "-", nullptr));
        label_13->setText(QCoreApplication::translate("Dialog", "<html><head/><body><p><img src=\":/images/coffee.jpg\"/></p></body></html>", nullptr));
        pushButton_13->setText(QCoreApplication::translate("Dialog", "-", nullptr));
        pushButton_5->setText(QCoreApplication::translate("Dialog", "-", nullptr));
        label_22->setText(QCoreApplication::translate("Dialog", "$2.99", nullptr));
        label_2->setText(QCoreApplication::translate("Dialog", "<html><head/><body><p><img src=\":/images/chicken.jpg\"/></p></body></html>", nullptr));
        label_15->setText(QCoreApplication::translate("Dialog", "<html><head/><body><p><img src=\":/images/onion_rings.jpg\"/></p></body></html>", nullptr));
        label_33->setText(QString());
        label_19->setText(QCoreApplication::translate("Dialog", "Onion Rings", nullptr));
        label_26->setText(QCoreApplication::translate("Dialog", "Order items:", nullptr));
        pushButton_12->setText(QCoreApplication::translate("Dialog", "+", nullptr));
        label_25->setText(QCoreApplication::translate("Dialog", "$5.99", nullptr));
        label_24->setText(QCoreApplication::translate("Dialog", "$10.99", nullptr));
        label_4->setText(QCoreApplication::translate("Dialog", "<html><head/><body><p><img src=\":/new/prefix1/images/Chicken_Tacos.jpg\"/><img src=\":/images/Chicken_Tacos.jpg\"/></p></body></html>", nullptr));
        pushButton_9->setText(QCoreApplication::translate("Dialog", "-", nullptr));
        label_23->setText(QCoreApplication::translate("Dialog", "$3.99", nullptr));
        pushButton_7->setText(QCoreApplication::translate("Dialog", "-", nullptr));
        pushButton_10->setText(QCoreApplication::translate("Dialog", "+", nullptr));
        label_28->setText(QCoreApplication::translate("Dialog", "Rate:", nullptr));
        label_31->setText(QCoreApplication::translate("Dialog", "Rate:", nullptr));
        label_14->setText(QCoreApplication::translate("Dialog", "<html><head/><body><p><img src=\":/images/french_fries.jpg\"/></p></body></html>", nullptr));
        label_27->setText(QCoreApplication::translate("Dialog", "Rate:", nullptr));
        label_38->setText(QString());
        label_20->setText(QCoreApplication::translate("Dialog", "Coffee", nullptr));
        label_32->setText(QString());
        label_7->setText(QCoreApplication::translate("Dialog", "<html><head/><body><p><img src=\":/images/Chicken_Tacos.jpg\"/></p></body></html>", nullptr));
        label_39->setText(QCoreApplication::translate("Dialog", "Table", nullptr));
        label_40->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class Dialog: public Ui_Dialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALOG_H
