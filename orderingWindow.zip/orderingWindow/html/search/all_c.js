var searchData=
[
  ['receivedata_67',['receiveData',['../classDialog.html#ae634500bd7c141cb893943c5b4885419',1,'Dialog::receiveData()'],['../classRestaurant.html#a55afd38915b8aa0d523d9e00ae6b3cd0',1,'Restaurant::receiveData()']]],
  ['receivedata2_68',['receiveData2',['../classDialog.html#a4d7104ee2db8bceea3877a68e245a710',1,'Dialog::receiveData2()'],['../classRestaurant.html#afd5a50c585a9b37d103e1e30cdcfa6a3',1,'Restaurant::receiveData2()']]],
  ['receivedata3_69',['receiveData3',['../classDialog.html#aba35607f20e7f47897ad0f264382e7a9',1,'Dialog::receiveData3()'],['../classRestaurant.html#a83386074f2013cb1f8af44d1fe7f225b',1,'Restaurant::receiveData3()']]],
  ['receivedata4_70',['receiveData4',['../classDialog.html#a1ef0eec6104c4aa8062c7db3bbbf6842',1,'Dialog::receiveData4()'],['../classRestaurant.html#ab5013a15e968ba939f9d23af53d47c3b',1,'Restaurant::receiveData4()']]],
  ['receivedata5_71',['receiveData5',['../classDialog.html#ab777e0a2b090292729a3fb0b4f32fc53',1,'Dialog::receiveData5()'],['../classRestaurant.html#a3f0a6ea4e7133d5533f62063ca63ddb7',1,'Restaurant::receiveData5()']]],
  ['receivedata6_72',['receiveData6',['../classDialog.html#aab093c6d6676eefa908111023e2b9b5d',1,'Dialog::receiveData6()'],['../classRestaurant.html#af38bcddb185712266badfb9534c9f818',1,'Restaurant::receiveData6()']]],
  ['removeorder_73',['removeOrder',['../classRestaurant.html#aaf70a1aa226e99b2ced76ea3fd68f9db',1,'Restaurant']]],
  ['restaurant_74',['Restaurant',['../classUi_1_1Restaurant.html',1,'Ui::Restaurant'],['../classRestaurant.html',1,'Restaurant'],['../classRestaurant.html#a77a34e85911381931008cf4454f54ec2',1,'Restaurant::Restaurant()']]]
];
