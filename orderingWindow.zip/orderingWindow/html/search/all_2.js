var searchData=
[
  ['dialog_4',['Dialog',['../classUi_1_1Dialog.html',1,'Ui::Dialog'],['../classDialog.html',1,'Dialog'],['../classDialog.html#a99e8c31c09fd87d2a967172f8f7b32db',1,'Dialog::Dialog()']]],
  ['dish_5',['Dish',['../classDish.html',1,'Dish'],['../classDish.html#a74a3fdca3207e85a762781116f2ff9e4',1,'Dish::Dish()']]],
  ['displayorders_6',['displayorders',['../classOrderQueue.html#a7dcc311beade6893f2a11c8413a0b823',1,'OrderQueue']]],
  ['displayorders_5fstr_7',['displayorders_str',['../classOrderQueue.html#afc69ea0f3e7fccc63e9781251ec4caaf',1,'OrderQueue']]]
];
