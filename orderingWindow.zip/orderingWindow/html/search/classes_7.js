var searchData=
[
  ['restaurant_113',['Restaurant',['../classUi_1_1Restaurant.html',1,'Ui::Restaurant'],['../classRestaurant.html',1,'Restaurant']]]
];
