var searchData=
[
  ['getdishnum_9',['getdishNum',['../classOrder.html#aee17fb0708e54ebe408d2fc336dcb033',1,'Order']]],
  ['gethead_10',['getHead',['../classOrderQueue.html#af510855e33247b2b744ec5afe338e0b7',1,'OrderQueue']]],
  ['getid_11',['getID',['../classDish.html#a3c70858f3eadca05d1f68001e47d1fc7',1,'Dish']]],
  ['getitems_12',['getItems',['../classOrder.html#a86b6148422d4b434908dbffb4a1c5f8f',1,'Order']]],
  ['getitems_5fstr_13',['getitems_str',['../classOrder.html#a279f0493cb68ae8c6fe31d5c84c5493a',1,'Order']]],
  ['getname_14',['getname',['../classDish.html#a9f22eb509c94f257da88c22172a9562b',1,'Dish']]],
  ['getorderid_15',['getorderID',['../classOrder.html#a5fbeaf30b3e0cd21d4e732f7d2eb8df1',1,'Order']]],
  ['getpic_16',['getpic',['../classDish.html#aa877f30a550928acc044f969de07f7ab',1,'Dish']]],
  ['getprice_17',['getprice',['../classDish.html#aa398ab21d337f82a50e0b980d3db9e84',1,'Dish::getprice()'],['../classOrder.html#a2abd620862024799d9e8957b6ed1c110',1,'Order::getprice()']]],
  ['getrate_18',['getrate',['../classDish.html#a1131368348eee14bc6bb58837ef28059',1,'Dish']]],
  ['getsize_19',['getsize',['../classOrderQueue.html#a9ebd61576e96adb890fc94ffb2d4c459',1,'OrderQueue']]],
  ['getstate_20',['getState',['../classOrder.html#a986dea9f3256b2d12d2e364b41b76f78',1,'Order']]],
  ['gettableid_21',['gettableID',['../classOrder.html#a15874fddac9e820df2bcd4c9c426e382',1,'Order']]],
  ['gettotalr_22',['getTotalR',['../classDish.html#a22001c86acea7e29cc595a8ee9ae2a64',1,'Dish']]],
  ['gettotals_23',['getTotalS',['../classDish.html#a5531c601cbcecb518a5fe238f29ffb4a',1,'Dish']]]
];
