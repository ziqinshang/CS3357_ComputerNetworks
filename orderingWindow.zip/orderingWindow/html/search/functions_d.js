var searchData=
[
  ['updaterate_202',['updaterate',['../classDish.html#a28eeb602bbfb9c3e53a34e4f9fe9b572',1,'Dish']]]
];
