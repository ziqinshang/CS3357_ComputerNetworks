var searchData=
[
  ['setid_190',['setID',['../classDish.html#aaf1b6a521eaf24e8f4e2727a5d448816',1,'Dish']]],
  ['setname_191',['setname',['../classDish.html#a77b910d6f3d651be2e898ac3a6a6d061',1,'Dish']]],
  ['setorderid_192',['setorderID',['../classOrder.html#a6dd2617ef8c70b23438161bdefcf1a2e',1,'Order']]],
  ['setpic_193',['setpic',['../classDish.html#a5f6b1f7fa378e8d776296055986a34da',1,'Dish']]],
  ['setprice_194',['setprice',['../classDish.html#a2d930e8759dbfa753241e1e516052e51',1,'Dish::setprice()'],['../classOrder.html#aff1a4c1305d5965a11a65e79330e0b41',1,'Order::setprice()'],['../classTable.html#aa7789bb25d6da70321109d21d8a98338',1,'Table::setPrice()']]],
  ['setrate_195',['setrate',['../classDish.html#ab6c56bbb4a93493286aaea078ddb7b0a',1,'Dish']]],
  ['setstate_196',['setState',['../classOrder.html#a0227b784bf90cf0e57975e30504b5e1e',1,'Order']]],
  ['settableid_197',['settableID',['../classOrder.html#ab2c6ddb6d751065fd2f48a5286fe0344',1,'Order']]],
  ['settotalr_198',['setTotalR',['../classDish.html#a5558762917a0e89e1d5ee48bbf75f026',1,'Dish']]],
  ['settotals_199',['setTotalS',['../classDish.html#a9eb2db52d74328c301512487c835a43c',1,'Dish']]]
];
