var searchData=
[
  ['needhelp_37',['needHelp',['../classneedHelp.html',1,'']]],
  ['neworder_38',['neworder',['../classTable.html#a427a8e0047a054ca03f95becffd98ae5',1,'Table']]]
];
