var searchData=
[
  ['appendorder_0',['appendorder',['../classOrderQueue.html#ab930caff3032d46719838b713fba1e21',1,'OrderQueue']]],
  ['averagerate_1',['averageRate',['../classDish.html#ac8beafdb6f64710962203ba27c2c21d2',1,'Dish']]]
];
