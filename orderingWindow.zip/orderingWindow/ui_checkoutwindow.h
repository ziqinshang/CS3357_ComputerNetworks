/********************************************************************************
** Form generated from reading UI file 'checkoutwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.15.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CHECKOUTWINDOW_H
#define UI_CHECKOUTWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QFrame>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_checkoutWindow
{
public:
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_5;
    QLabel *label_6;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;
    QLabel *label_7;
    QLabel *label_8;
    QLineEdit *lineEdit;
    QFrame *line_2;
    QFrame *line_3;
    QLabel *label_9;
    QLabel *label_10;
    QLabel *label_11;
    QLabel *label_12;
    QFrame *line_4;
    QLabel *label_13;
    QLabel *label_4;
    QLabel *label_14;
    QPushButton *pushButton_4;
    QFrame *line_5;
    QLabel *label_15;
    QPushButton *pushButton_5;
    QPushButton *pushButton_6;
    QPushButton *pushButton_7;

    void setupUi(QDialog *checkoutWindow)
    {
        if (checkoutWindow->objectName().isEmpty())
            checkoutWindow->setObjectName(QString::fromUtf8("checkoutWindow"));
        checkoutWindow->resize(857, 781);
        label = new QLabel(checkoutWindow);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(50, 20, 91, 31));
        QFont font;
        font.setPointSize(14);
        label->setFont(font);
        label_2 = new QLabel(checkoutWindow);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(80, 60, 51, 31));
        QFont font1;
        font1.setPointSize(11);
        label_2->setFont(font1);
        label_3 = new QLabel(checkoutWindow);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(120, 70, 47, 13));
        label_3->setFont(font1);
        label_5 = new QLabel(checkoutWindow);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(80, 190, 51, 31));
        label_5->setFont(font1);
        label_6 = new QLabel(checkoutWindow);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(80, 230, 81, 31));
        label_6->setFont(font1);
        pushButton = new QPushButton(checkoutWindow);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(80, 270, 91, 41));
        pushButton_2 = new QPushButton(checkoutWindow);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(220, 270, 81, 41));
        pushButton_3 = new QPushButton(checkoutWindow);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));
        pushButton_3->setGeometry(QRect(350, 270, 91, 41));
        label_7 = new QLabel(checkoutWindow);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setGeometry(QRect(80, 320, 81, 31));
        label_7->setFont(font1);
        label_8 = new QLabel(checkoutWindow);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        label_8->setGeometry(QRect(120, 360, 47, 13));
        label_8->setFont(font);
        lineEdit = new QLineEdit(checkoutWindow);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setGeometry(QRect(140, 360, 113, 20));
        line_2 = new QFrame(checkoutWindow);
        line_2->setObjectName(QString::fromUtf8("line_2"));
        line_2->setGeometry(QRect(-30, 400, 1131, 21));
        line_2->setFrameShape(QFrame::HLine);
        line_2->setFrameShadow(QFrame::Sunken);
        line_3 = new QFrame(checkoutWindow);
        line_3->setObjectName(QString::fromUtf8("line_3"));
        line_3->setGeometry(QRect(10, 50, 1131, 21));
        line_3->setFrameShape(QFrame::HLine);
        line_3->setFrameShadow(QFrame::Sunken);
        label_9 = new QLabel(checkoutWindow);
        label_9->setObjectName(QString::fromUtf8("label_9"));
        label_9->setGeometry(QRect(60, 440, 91, 41));
        label_9->setFont(font1);
        label_10 = new QLabel(checkoutWindow);
        label_10->setObjectName(QString::fromUtf8("label_10"));
        label_10->setGeometry(QRect(150, 450, 47, 20));
        label_10->setFont(font);
        label_11 = new QLabel(checkoutWindow);
        label_11->setObjectName(QString::fromUtf8("label_11"));
        label_11->setGeometry(QRect(190, 370, 71, 21));
        QFont font2;
        font2.setFamily(QString::fromUtf8("MS Shell Dlg 2"));
        font2.setPointSize(8);
        font2.setBold(false);
        font2.setItalic(false);
        font2.setUnderline(true);
        font2.setWeight(50);
        label_11->setFont(font2);
        label_11->setStyleSheet(QString::fromUtf8("font: 8pt \"MS Shell Dlg 2\";\n"
"text-decoration: underline;"));
        label_12 = new QLabel(checkoutWindow);
        label_12->setObjectName(QString::fromUtf8("label_12"));
        label_12->setGeometry(QRect(80, 100, 91, 41));
        label_12->setFont(font1);
        line_4 = new QFrame(checkoutWindow);
        line_4->setObjectName(QString::fromUtf8("line_4"));
        line_4->setGeometry(QRect(-10, 170, 1131, 21));
        line_4->setFrameShape(QFrame::HLine);
        line_4->setFrameShadow(QFrame::Sunken);
        label_13 = new QLabel(checkoutWindow);
        label_13->setObjectName(QString::fromUtf8("label_13"));
        label_13->setGeometry(QRect(170, 110, 47, 20));
        label_13->setFont(font);
        label_4 = new QLabel(checkoutWindow);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(190, 110, 71, 21));
        label_4->setFont(font1);
        label_14 = new QLabel(checkoutWindow);
        label_14->setObjectName(QString::fromUtf8("label_14"));
        label_14->setGeometry(QRect(170, 450, 71, 21));
        label_14->setFont(font1);
        pushButton_4 = new QPushButton(checkoutWindow);
        pushButton_4->setObjectName(QString::fromUtf8("pushButton_4"));
        pushButton_4->setGeometry(QRect(290, 360, 91, 31));
        pushButton_4->setFont(font1);
        line_5 = new QFrame(checkoutWindow);
        line_5->setObjectName(QString::fromUtf8("line_5"));
        line_5->setGeometry(QRect(-10, 520, 1131, 21));
        line_5->setFrameShape(QFrame::HLine);
        line_5->setFrameShadow(QFrame::Sunken);
        label_15 = new QLabel(checkoutWindow);
        label_15->setObjectName(QString::fromUtf8("label_15"));
        label_15->setGeometry(QRect(60, 550, 141, 41));
        QFont font3;
        font3.setPointSize(12);
        label_15->setFont(font3);
        pushButton_5 = new QPushButton(checkoutWindow);
        pushButton_5->setObjectName(QString::fromUtf8("pushButton_5"));
        pushButton_5->setGeometry(QRect(70, 620, 121, 61));
        pushButton_5->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"background-color: rgb(255, 255, 255);\n"
""));
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/images/cash.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_5->setIcon(icon);
        pushButton_5->setIconSize(QSize(121, 51));
        pushButton_6 = new QPushButton(checkoutWindow);
        pushButton_6->setObjectName(QString::fromUtf8("pushButton_6"));
        pushButton_6->setGeometry(QRect(270, 620, 121, 61));
        pushButton_6->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        QIcon icon1;
        icon1.addFile(QString::fromUtf8(":/images/ApplePay.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_6->setIcon(icon1);
        pushButton_6->setIconSize(QSize(121, 51));
        pushButton_7 = new QPushButton(checkoutWindow);
        pushButton_7->setObjectName(QString::fromUtf8("pushButton_7"));
        pushButton_7->setGeometry(QRect(460, 620, 121, 61));
        pushButton_7->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        QIcon icon2;
        icon2.addFile(QString::fromUtf8(":/images/Visa.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_7->setIcon(icon2);
        pushButton_7->setIconSize(QSize(121, 51));

        retranslateUi(checkoutWindow);

        QMetaObject::connectSlotsByName(checkoutWindow);
    } // setupUi

    void retranslateUi(QDialog *checkoutWindow)
    {
        checkoutWindow->setWindowTitle(QCoreApplication::translate("checkoutWindow", "Dialog", nullptr));
        label->setText(QCoreApplication::translate("checkoutWindow", "Check Out", nullptr));
        label_2->setText(QCoreApplication::translate("checkoutWindow", "Table", nullptr));
        label_3->setText(QString());
        label_5->setText(QCoreApplication::translate("checkoutWindow", "Tip:", nullptr));
        label_6->setText(QCoreApplication::translate("checkoutWindow", "By Percent", nullptr));
        pushButton->setText(QCoreApplication::translate("checkoutWindow", "10%", nullptr));
        pushButton_2->setText(QCoreApplication::translate("checkoutWindow", "12%", nullptr));
        pushButton_3->setText(QCoreApplication::translate("checkoutWindow", "15%", nullptr));
        label_7->setText(QCoreApplication::translate("checkoutWindow", "By Amount", nullptr));
        label_8->setText(QCoreApplication::translate("checkoutWindow", "$", nullptr));
        label_9->setText(QCoreApplication::translate("checkoutWindow", "Total Price:", nullptr));
        label_10->setText(QCoreApplication::translate("checkoutWindow", "$", nullptr));
        label_11->setText(QString());
        label_12->setText(QCoreApplication::translate("checkoutWindow", "Order Price:", nullptr));
        label_13->setText(QCoreApplication::translate("checkoutWindow", "$", nullptr));
        label_4->setText(QCoreApplication::translate("checkoutWindow", "TextLabel", nullptr));
        label_14->setText(QString());
        pushButton_4->setText(QCoreApplication::translate("checkoutWindow", "Confirm", nullptr));
        label_15->setText(QCoreApplication::translate("checkoutWindow", "Payment methods:", nullptr));
        pushButton_5->setText(QString());
        pushButton_6->setText(QString());
        pushButton_7->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class checkoutWindow: public Ui_checkoutWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CHECKOUTWINDOW_H
